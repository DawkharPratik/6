import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

class ServletCust extends HttpServlet
{
    protected void doPost(HttpServletRequest req, HttpServletResponse res)throws ServletException,IOException
    {
      res.setContentType("text/html");
      PrintWriter out = res.getWriter(); 
      String cno = req.getParameter("no");
      try
      {
         Class.forName("org.postgresql.Driver");
         Connection cn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/tybcs", "postgres", "root");
         PreparedStatement pst = cn.prepareStatement("select * from customer where cno = ? ");
         pst.setString(1,cno);
         
         ResultSet rs = pst.executeQuery();
         if(rs.next())
         {
           String cname = rs.getString("name");
           String caddres = rs.getString("address");
           out.println("<html>");
           out.println("<body>");
           out.println("<h2>Customer Details</h2>");
           out.println("<p>Customer Number :"+ cno +"</p>");
           out.println("<p>Customer Name :"+ cname +"</p>");
           out.println("<p>Customer Address :"+ caddres +"</p>");
           out.println("</body>");
           out.println("</html>");
        }
        else
        {
            out.println("<html>");
            out.println("<body>");
            out.println("<h2>Error</h2>");
            out.println("<p>Customer Number " + cno + "is not found </p>");
            out.println("</body>");
            out.println("</html>");
        }
        cn.close();
        pst.close();
        rs.close();
        out.close();
     }
     catch(SQLException se) {  
         out.println("<html><body><h2>Error</h2><p>SQLException occurred: " + se.getMessage() + "</p></body></html>");
     }
     catch(Exception e) {
         out.println("<html><body><h2>Error</h2><p>Exception occurred: " + e.getMessage() + "</p></body></html>");
    }

  }
}      
         
