import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class ServletInfo extends HttpServlet {
    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        res.setContentType("text/html");
        PrintWriter out = res.getWriter();
        out.println("<html>");
        out.println("<body>");
        out.println("<h2>Information about Http Request</h2>");
        out.println("<br>Server Name: " + req.getServerName());
        out.println("<br>Server Port: " + req.getServerPort());
        out.println("<br>IP Address: " + req.getRemoteAddr());
        out.println("<br>Client Browser: " + req.getHeader("User-Agent"));
        out.println("</body>");
        out.println("</html>");
        out.close();
    }
}
