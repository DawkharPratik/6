import java.io.*;

class Alpha extends Thread
{

  char c;
  public void run()
  {
     try
     {
        for(c='A';c<='Z';c++)
        {
            System.out.println(" "+c);
            Thread.sleep(2000);
        } 
     }
     catch(Exception e)
     {
        System.out.println("Exception Occured");
     }
  }   
}     

class Multi
{
   public static void main(String args[])
   {
      Alpha t = new Alpha();
      t.start();
   }
}  
