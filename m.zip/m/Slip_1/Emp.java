import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;

class Emp extends Frame implements ActionListener 
{
    Label l1, l2, l3, l4;
    TextField t1, t2, t3, t4;
    Button b;
    
    public Emp() 
    {
        setLayout(null);
        l1 = new Label("Eno");
        l2 = new Label("EName");
        l3 = new Label("Designation");
        l4 = new Label("Salary");
        t1 = new TextField();
        t2 = new TextField();
        t3 = new TextField();
        t4 = new TextField();
        b  = new Button("Save");
        l1.setBounds(50, 50, 100, 30);
        t1.setBounds(160, 50, 100, 30);
        l2.setBounds(50, 90, 100, 30);
        t2.setBounds(160, 90, 100, 30);
        l3.setBounds(50, 130, 100, 30);
        t3.setBounds(160, 130, 100, 30);
        l4.setBounds(50, 180, 100, 30);
        t4.setBounds(160, 180, 100, 30);
        b.setBounds(50, 250, 100, 30);
        add(l1);
        add(t1);
        add(l2);
        add(t2);
        add(l3);
        add(t3);
        add(l4);
        add(t4);
        add(b);
        b.addActionListener(this);
        setSize(500, 500);
        setVisible(true);
        addWindowListener(new WindowAdapter() 
        {
            public void windowClosing(WindowEvent e) 
            {
                dispose();
            }
        });
    }

    public void actionPerformed(ActionEvent oe) 
    {
        String str = oe.getActionCommand();
        if (str.equals("Save")) 
        {
            try 
            {
                Class.forName("org.postgresql.Driver");
                Connection cn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/tybcs", "postgres", "root");
                Statement st = cn.createStatement();

                int en = Integer.parseInt(t1.getText());
                String enn = t2.getText();
                String des = t3.getText();
                int sal = Integer.parseInt(t4.getText());
                String strr = "insert into employee values(" + en + ",'" + enn + "','" + des + "',"+ sal + ")";
                int k = st.executeUpdate(strr);
                if (k > 0) 
                {
                    JOptionPane.showMessageDialog(null, "Record Inserted  Successfully");
                }
                cn.close();
            } 
            catch (Exception ex) 
            {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage());
            }
        }
    }

    public static void main(String args[])throws SQLException,Exception
    {
        new Emp();
    }
}
