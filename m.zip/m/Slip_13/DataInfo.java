import java.sql.*;

class DataInfo
{
   public static void main(String args[]throws SQLException,Exception
   {
      try
      {
         Class.forName("org.postgresql.Driver");
         Connection cn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/tybcs", "postgres", "root");
         DatabaseMetaData dmd = con.getMetaData();
         
         System.out.println("User Name:"+dmd.getUserName());
         System.out.println("URL: "+dmd.getURL());
         System.out.println("Database Product Name: "+dmd.getDatabaseProductName());
         System.out.println("Database Version Name: "+dmd.getDatabaseProductVersion());
         System.out.println("Driver Name: "+dmd.getDriverName());
         System.out.println("Driver Version: "+dmd.getDriverVersion());
         
         ResultSet rs = dmd.getTables(null,null,null,new String[]{"TABLE"});
         System.out.println("table_cat\ttable_schem\ttable_name\ttable_type\tremarks");
         
         while(rs.next())
         {
            System.out.println(rs.getString("table_cat")+"\t"+rs.getString("table_schem")+"\t"+rs.getString("table_name")+"\t"+rs.getString("table_type")+"\t"+rs.getString("remarks"));
         }      
      }
      catch(SQLException se)
      {
         System.out.println("SQL Exception occured");
      }
  }
}
