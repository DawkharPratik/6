
/*Design a servlet that provides information
-IP-Address
-browser type
-operating system type
-names of currently loaded servlets. 
/serv
*/
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class serv extends HttpServlet {
    public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        res.setContentType("text/html");
        PrintWriter out = res.getWriter();
        out.println("<br>Ip-Address : " + req.getRemoteAddr());
        out.println("<br>Browser Type : " + req.getHeader("User-Agent"));
        out.println("<br>os : " + System.getProperty("os.name"));
        out.println("<br> servlet name : " + getServletName());
    }
}
