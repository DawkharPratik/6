
//Write a java program to read ‘N’ names of your friends, store it into HashSet and display them in ascending order
import java.util.*;

public class s2q1 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter how many name : ");
        int n = sc.nextInt();

        HashSet<String> hs = new HashSet<>();
        for (int i = 0; i < n; i++) {
            System.out.println("Enter name : ");
            String name = sc.next();
            hs.add(name);
        }

        ArrayList<String> sortedList = new ArrayList<>(hs);
        Collections.sort(sortedList);

        System.out.println("Name of friends in sorted order : ");
        for (String name : sortedList) {
            System.out.println(name + " ");
        }
        sc.close();
    }
}