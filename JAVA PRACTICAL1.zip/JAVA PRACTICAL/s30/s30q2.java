
//Write a Java Program for the implementation of scrollable ResultSet. Assume Teacher table with attributes (TID, TName, Salary) is already created. 
import java.sql.*;

class s30q2 {
        public static void main(String[] args) {
                try {
                        // load the driver
                        Class.forName("com.mysql.cj.jdbc.Driver");
                        // create connection
                        Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/tybcs", "root",
                                        "Ganesh");
                        // create statement
                        Statement st = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
                                        ResultSet.CONCUR_READ_ONLY);
                        // create resultset object
                        ResultSet rs = st.executeQuery("Select * from teacher");

                        while (rs.next()) {
                                System.out.print(" TID " + rs.getInt(1));
                                System.out.print(" TName" + rs.getString(2));
                                System.out.print(" Salary" + rs.getDouble(3));
                                System.out.println();
                        }

                        rs.last();

                        System.out.println("Last row - TID: " + rs.getInt(1) + ", TName: " + rs.getString(2)
                                        + ", Salary: " + rs.getDouble(3));

                        rs.first();
                        System.out.println("Last row - TID: " + rs.getInt("TID") + ", TName: " + rs.getString("TName")
                                        + ", Salary: " + rs.getDouble("Salary"));

                        rs.absolute(1);
                        System.out.println("Last row - TID: " + rs.getInt("TID") + ", TName: " + rs.getString("TName")
                                        + ", Salary: " + rs.getDouble("Salary"));

                        conn.close();

                } catch (Exception e) {
                        System.out.println("error : " + e);
                }
        }
}
