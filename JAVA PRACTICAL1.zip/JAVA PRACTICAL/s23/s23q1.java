
//Write a java program using Multithreading to accept a String from a user and display each vowel from a String after every 3 seconds. 
import java.util.Scanner;

public class s23q1 implements Runnable {
    private String inputString;

    public s23q1(String inputString) {
        this.inputString = inputString;
    }

    @Override
    public void run() {
        for (int i = 0; i < inputString.length(); i++) {
            char ch = inputString.charAt(i);
            if (isVowel(ch)) {
                System.out.println(ch);
                try {
                    Thread.sleep(3000); // Sleep for 3 seconds
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private boolean isVowel(char ch) {
        ch = Character.toLowerCase(ch);
        return ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u';
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter a string: ");
        String inputString = scanner.nextLine();

        // Create a thread to print vowels
        Thread vowelThread = new Thread(new s23q1(inputString));
        vowelThread.start();
        scanner.close();
    }
}
