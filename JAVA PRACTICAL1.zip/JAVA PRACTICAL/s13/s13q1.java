
//Write a Java program to display information about the database and list all the tables in the database. (Use DatabaseMetaData). 
import java.sql.*;

public class s13q1 {
    // JDBC URL, username, and password of MySQL server
    private static final String URL = "jdbc:mysql://localhost:3306/tybcs";
    private static final String USER = "root";
    private static final String PASSWORD = "Ganesh";

    public static void main(String[] args) {
        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD)) {
            // Get DatabaseMetaData
            DatabaseMetaData metaData = connection.getMetaData();

            // Display database information
            System.out.println("Database Information:");
            System.out.println("Database Product Name: " + metaData.getDatabaseProductName());
            System.out.println("Database Product Version: " + metaData.getDatabaseProductVersion());
            System.out.println("Driver Name: " + metaData.getDriverName());
            System.out.println("Driver Version: " + metaData.getDriverVersion());

            // Get tables in the database
            ResultSet resultSet = metaData.getTables(null, null, null, new String[] { "TABLE" });
            System.out.println("\nTables in the Database:");
            while (resultSet.next()) {
                String tableName = resultSet.getString("TABLE_NAME");
                System.out.println(tableName);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
