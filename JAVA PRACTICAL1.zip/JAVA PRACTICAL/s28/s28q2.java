//Write a java program to display name of currently executing Thread in multithreading.
public class s28q2 {

    public static void main(String[] args) {
        Thread t = new Thread(() -> {
            String threadName = Thread.currentThread().getName();
            System.out.println("Currently executing thread is : " + threadName);
        });
        t.start();
    }
}