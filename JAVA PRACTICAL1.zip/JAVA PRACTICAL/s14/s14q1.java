
//Write a Java program using Multithreading for a simple search engine. Accept a string to be searched. Search the string in all text files in the current folder. Use a separate thread for each file. The result should display the filename and line number where the string is found. 
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class s14q1 {
    private static final String SEARCH_STRING = "your_search_string"; // Change this to the string you want to search

    public static void main(String[] args) {
        File folder = new File(".");
        File[] files = folder.listFiles((dir, name) -> name.endsWith(".txt")); // Get all text files in the current
        // folder

        for (File file : files) {
            new Thread(() -> searchInFile(file)).start(); // Start a separate thread for each file
        }
    }

    private static void searchInFile(File file) {
        String fileName = file.getName();
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            int lineNumber = 0;
            while ((line = reader.readLine()) != null) {
                lineNumber++;
                if (line.contains(SEARCH_STRING)) {
                    System.out
                            .println("Found '" + SEARCH_STRING + "' in file: " + fileName + " at line: " + lineNumber);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
