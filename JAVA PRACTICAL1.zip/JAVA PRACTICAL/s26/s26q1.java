//Write a Java program to delete the details of given employee (ENo EName Salary). Accept employee ID through command line. (Use PreparedStatement Interface)

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class s26q1 {
    // JDBC URL, username, and password of MySQL server
    private static final String URL = "jdbc:mysql://localhost:3306/tybcs";
    private static final String USER = "root";
    private static final String PASSWORD = "Ganesh";

    public static void main(String[] args) {
        if (args.length != 1) {
            System.out.println("Usage: java DeleteEmployeeDetails <EmployeeID>");
            return;
        }

        int employeeID = Integer.parseInt(args[0]);

        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD)) {
            deleteEmployee(connection, employeeID);
            System.out.println("Employee details with ID " + employeeID + " deleted successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void deleteEmployee(Connection connection, int employeeID) throws SQLException {
        // SQL query to delete employee details based on employee ID
        String deleteQuery = "DELETE FROM Employee WHERE ENo = ?";

        // Create PreparedStatement
        PreparedStatement preparedStatement = connection.prepareStatement(deleteQuery);

        // Set employee ID parameter
        preparedStatement.setInt(1, employeeID);

        // Execute the delete query
        int rowsAffected = preparedStatement.executeUpdate();
        if (rowsAffected == 0) {
            System.out.println("Employee with ID " + employeeID + " not found.");
        }
    }
}
