//Write a JSP program to check whether a given number is prime or not. Display the result in red color. 
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<title>Prime Number Checker</title>
</head>
<body>
    <h2>Prime Number Checker</h2>
    
    <%!
        // Method to check if a number is prime
        boolean isPrime(int number) {
            if (number <= 1) {
                return false;
            }
            for (int i = 2; i <= Math.sqrt(number); i++) {
                if (number % i == 0) {
                    return false;
                }
            }
            return true;
        }
    %>
    
    <%
        // Getting the number from the request parameter
        //int num = Integer.parseInt(request.getParameter("number"));
        
        // Checking if the number is prime
        boolean prime = isPrime(12);
        
        // Displaying the result in red color if prime, otherwise in black
        //String color = prime ? "red" : "black";
    %>
    
    <p style="color: red;">
        <%= 12 %> is <%= prime ? "" : "not " %>prime.
    </p>
    
</body>
</html>
