
//Write a Java program to display information about all columns in the DONAR table using ResultSetMetaData. 
import java.sql.*;

public class s11q2 {

    public static void main(String[] args) {
        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/tybcs", "root",
                "Ganesh")) {
            // Create a statement
            Statement statement = connection.createStatement();

            // Execute a query to select all columns from the DONAR table
            ResultSet resultSet = statement.executeQuery("SELECT * FROM DONAR");

            // Get the ResultSetMetaData
            ResultSetMetaData metaData = resultSet.getMetaData();

            // Get the number of columns
            int columnCount = metaData.getColumnCount();

            // Print column information
            System.out.println("Column Information for DONAR table:");
            for (int i = 1; i <= columnCount; i++) {
                System.out.println("Column Name: " + metaData.getColumnName(i));
                System.out.println("Data Type: " + metaData.getColumnTypeName(i));
                System.out.println(
                        "Is Nullable: " + (metaData.isNullable(i) == ResultSetMetaData.columnNullable ? "Yes" : "No"));
                System.out.println("-----------------------------------");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
