
//Design an HTML page which passes customer number to a search servlet. The servlet searches for the customer number in a database (customer table) and returns customer details if found the number otherwise display error message.
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/SearchServlet")
public class SearchServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Get customer number from request parameter
        String customerNumber = request.getParameter("customerNumber");

        // Implement your database search logic here
        // For simplicity, let's assume a customer is found if the customer number is
        // "123456"
        if ("123456".equals(customerNumber)) {
            // Simulate fetching customer details from the database
            String customerName = "John Doe";
            String customerEmail = "john@example.com";

            // Display customer details
            PrintWriter out = response.getWriter();
            out.println("<html><body>");
            out.println("<h2>Customer Details</h2>");
            out.println("<p>Customer Number: " + customerNumber + "</p>");
            out.println("<p>Customer Name: " + customerName + "</p>");
            out.println("<p>Customer Email: " + customerEmail + "</p>");
            out.println("</body></html>");
        } else {
            // If customer not found, display error message
            PrintWriter out = response.getWriter();
            out.println("<html><body>");
            out.println("<h2>Error</h2>");
            out.println("<p>Customer with number " + customerNumber + " not found.</p>");
            out.println("</body></html>");
        }
    }
}
