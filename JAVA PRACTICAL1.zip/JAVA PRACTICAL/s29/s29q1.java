
//Write a Java program to display information about all columns in the DONAR table using ResultSetMetaData. 
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

public class s29q1 {
    // JDBC URL, username, and password of MySQL server
    private static final String URL = "jdbc:mysql://localhost:3306/your_database_name";
    private static final String USER = "your_username";
    private static final String PASSWORD = "your_password";

    public static void main(String[] args) {
        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD)) {
            // Create a statement object
            Statement statement = connection.createStatement();

            // Execute query to retrieve all columns from DONAR table
            ResultSet resultSet = statement.executeQuery("SELECT * FROM DONAR");

            // Get ResultSetMetaData
            ResultSetMetaData metaData = resultSet.getMetaData();

            // Get number of columns
            int columnCount = metaData.getColumnCount();

            // Display information about each column
            System.out.println("Column information for DONAR table:");
            for (int i = 1; i <= columnCount; i++) {
                String columnName = metaData.getColumnName(i);
                String columnType = metaData.getColumnTypeName(i);
                int columnSize = metaData.getColumnDisplaySize(i);
                System.out.println(
                        "Column Name: " + columnName + ", Column Type: " + columnType + ", Column Size: " + columnSize);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
