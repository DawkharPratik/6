import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class TrafficSignalSimulation extends JFrame {
    private JLabel signalLabel;

    private boolean running = true;
    private int currentSignal = 0; // 0 for red, 1 for yellow, 2 for green

    public TrafficSignalSimulation() {
        setTitle("Traffic Signal Simulation");
        setSize(200, 300);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        signalLabel = new JLabel();
        signalLabel.setFont(new Font("Arial", Font.BOLD, 40));
        signalLabel.setHorizontalAlignment(JLabel.CENTER);
        updateSignal();

        add(signalLabel);

        Thread signalThread = new Thread(new SignalRunnable());
        signalThread.start();
    }

    private void updateSignal() {
        switch (currentSignal) {
            case 0:
                signalLabel.setText("RED");
                signalLabel.setForeground(Color.RED);
                break;
            case 1:
                signalLabel.setText("YELLOW");
                signalLabel.setForeground(Color.YELLOW);
                break;
            case 2:
                signalLabel.setText("GREEN");
                signalLabel.setForeground(Color.GREEN);
                break;
        }
    }

    private class SignalRunnable implements Runnable {
        @Override
        public void run() {
            try {
                while (running) {
                    Thread.sleep(getSignalDuration(currentSignal) * 1000);
                    currentSignal = (currentSignal + 1) % 3;
                    updateSignal();
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        private int getSignalDuration(int signal) {
            switch (signal) {
                case 0:
                    return 5; // Red signal duration in seconds
                case 1:
                    return 2; // Yellow signal duration in seconds
                case 2:
                    return 5; // Green signal duration in seconds
                default:
                    return 0;
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new TrafficSignalSimulation().setVisible(true);
        });
    }
}
