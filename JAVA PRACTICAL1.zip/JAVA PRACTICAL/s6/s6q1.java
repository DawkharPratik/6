
//Write a Java program to accept ‘n’ integers from the user and store them in a Collection. Display them in the sorted order. The collection should not accept duplicate elements. (Use a suitable collection). Search for a particular element using predefined search method in the Collection framework.
import java.util.*;

public class s6q1 {
    public static Set<Integer> set = new HashSet<>();

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.println("Enter how many numebr : ");
        int n = sc.nextInt();

        for (int i = 0; i < n; i++) {
            System.out.println("Enter number : ");
            int num = sc.nextInt();
            if (set.contains(num)) {
                System.out.println("this numebr already in collection.");
            } else {
                set.add(num);
            }
        }

        System.out.println("Enter number to search : ");
        int num = sc.nextInt();
        search(num);

        sc.close();
    }

    public static void search(int num) {
        if (set.contains(num)) {
            System.out.println("Number is fount in set ");
        } else {
            System.out.println("numbr not found");
        }
    }
}