//Write a Java program using Multithreading to display all the alphabets between ‘A’ to ‘Z’ after every 2 seconds.
class AlphabetPrinter implements Runnable {
    public void run() {
        char alphabet = 'A';

        try {
            while (alphabet <= 'Z') {
                System.out.print(alphabet + " ");
                alphabet++;
                Thread.sleep(2000);
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}

public class s1q1 {
    public static void main(String[] args) {
        AlphabetPrinter ap = new AlphabetPrinter();
        Thread thread = new Thread(ap);
        thread.start();
    }
}