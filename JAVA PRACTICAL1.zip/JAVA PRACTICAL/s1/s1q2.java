
//Write a Java program to accept the details of Employee (Eno, EName, Designation,Salary) from a user and store it into the database. (Use Swing)
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class s1q2 extends JFrame {
    private JTextField txtEno, txtEname, txtDesignation, txtSalary;
    private JButton btnSave;

    public s1q2() {
        setTitle("Employee Details Form");
        setSize(300, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new GridLayout(5, 2));
        panel.add(new JLabel("Employee Number:"));
        txtEno = new JTextField();
        panel.add(txtEno);
        panel.add(new JLabel("Employee Name:"));
        txtEname = new JTextField();
        panel.add(txtEname);
        panel.add(new JLabel("Designation:"));
        txtDesignation = new JTextField();
        panel.add(txtDesignation);
        panel.add(new JLabel("Salary:"));
        txtSalary = new JTextField();
        panel.add(txtSalary);

        btnSave = new JButton("Save");
        btnSave.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                saveEmployeeDetails();
            }
        });
        panel.add(btnSave);

        add(panel);
    }

    private void saveEmployeeDetails() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            // Establishing database connection
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/tybcs", "root",
                    "Ganesh");

            // Creating SQL query
            String sql = "INSERT INTO employees (Eno, EName, Designation, Salary) VALUES (?, ?, ?, ?)";
            PreparedStatement statement = conn.prepareStatement(sql);
            statement.setString(1, txtEno.getText());
            statement.setString(2, txtEname.getText());
            statement.setString(3, txtDesignation.getText());
            statement.setString(4, txtSalary.getText());

            // Executing query
            int rowsInserted = statement.executeUpdate();
            if (rowsInserted > 0) {
                JOptionPane.showMessageDialog(this, "Employee details saved successfully!");
            }

            // Closing database connection
            conn.close();
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new s1q2().setVisible(true);
            }
        });
    }
}
