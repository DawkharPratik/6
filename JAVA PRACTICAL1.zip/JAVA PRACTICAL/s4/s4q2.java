/*Write a Java program to store city names and their STD codes using an appropriate
collection and perform following operations:
i. Add a new city and its code (No duplicates)
ii. Remove a city from the collection
iii. Search for a city name and display the code*/

import java.util.HashMap;
import java.util.Map;
import java.util.*;

public class s4q2 {

    private static Map<String, Integer> citySTDMap = new HashMap<>();

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int choice;

        do {
            System.out.println("\n1. Add a new city and its code :");
            System.out.println("\n2. Remove a city from the collection : ");
            System.out.println("\n3. Search for city name and display its code : ");
            System.out.println("\n4. Exit");
            System.out.println("Enter your choice : ");
            choice = sc.nextInt();
            sc.nextLine();

            switch (choice) {
                case 1:
                    addCity(sc);
                    break;

                case 2:
                    removeCity(sc);
                    break;

                case 3:
                    searchCity(sc);
                    break;

                case 4:
                    System.out.println("Exiting program : ");
                    break;

                default:
                    System.out.println("Invalid choice : ");
                    break;
            }
        } while (choice != 4);

        sc.close();
    }

    private static void addCity(Scanner sc) {
        System.out.println("Enter city name : ");
        String city = sc.next();
        System.out.println("Enter city code ");
        int stdCode = sc.nextInt();

        if (citySTDMap.containsKey(city)) {
            System.out.println("city already exist..");
        } else {
            citySTDMap.put(city, stdCode);
            System.out.println("City and code added successfully.");
        }
    }

    private static void removeCity(Scanner sc) {
        System.out.println("Enter city name : ");
        String city = sc.next();

        if (citySTDMap.containsKey(city)) {
            citySTDMap.remove(city);
            System.out.println("City has been remove.");
        } else {
            System.out.println("City does not found");
        }
    }

    private static void searchCity(Scanner sc) {
        System.out.println("Enter city name ");
        String city = sc.nextLine();

        if (citySTDMap.containsKey(city)) {
            System.out.println("code of " + city + "is" + citySTDMap.get(city));
        } else {
            System.out.println("city not found");
        }
    }

}
