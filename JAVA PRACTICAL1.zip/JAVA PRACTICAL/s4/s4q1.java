import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class s4q1 implements Runnable {
    private JLabel label;
    private boolean blinking = true;

    public s4q1(JLabel label) {
        this.label = label;
    }

    @Override
    public void run() {
        try {
            while (blinking) {
                label.setVisible(false);
                Thread.sleep(500); // 500 milliseconds
                label.setVisible(true);
                Thread.sleep(500); // 500 milliseconds
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public void stopBlinking() {
        blinking = false;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                JFrame frame = new JFrame("Blinking Text");
                frame.setSize(300, 200);
                frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

                JLabel label = new JLabel("Blinking Text");
                frame.add(label, BorderLayout.CENTER);

                s4q1 blinkingText = new s4q1(label);
                Thread thread = new Thread(blinkingText);
                thread.start();

                frame.setVisible(true);

                frame.addWindowListener(new WindowAdapter() {
                    public void windowClosing(WindowEvent e) {
                        blinkingText.stopBlinking();
                    }
                });
            }
        });
    }
}
