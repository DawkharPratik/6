
//Write a SERVLET program to change inactive time interval of session.
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/ChangeSessionTimeoutServlet")
public class s27q2 extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Get the new inactive time interval from request parameter
        int newTimeout = Integer.parseInt(request.getParameter("timeout"));

        // Get the session, or create one if it doesn't exist
        HttpSession session = request.getSession();

        // Set the new inactive time interval for the session
        session.setMaxInactiveInterval(newTimeout);

        // Redirect to a page indicating the change is successful
        response.sendRedirect("timeout_changed.html");
    }
}
