// Write a java program to display name and priority of a Thread.
public class s15q1 {
    public static void main(String[] args) {
        Thread thread = Thread.currentThread(); // Get the current thread

        // Display name and priority of the thread
        System.out.println("Thread Name: " + thread.getName());
        System.out.println("Thread Priority: " + thread.getPriority());
    }
}
