
//Write a Java program to accept the details of Teacher (TNo, TName, Subject). Insert at least 5 Records into Teacher Table and display the details of Teacher who is teaching “JAVA” Subject. (Use PreparedStatement Interface) 
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class s16q2 {
    // JDBC URL, username, and password of MySQL server
    private static final String URL = "jdbc:mysql://localhost:3306/your_database_name";
    private static final String USER = "your_username";
    private static final String PASSWORD = "your_password";

    public static void main(String[] args) {
        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD)) {
            // Insert records into Teacher table
            insertRecords(connection);

            // Display details of teachers teaching "JAVA" subject
            displayJavaTeachers(connection);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void insertRecords(Connection connection) throws SQLException {
        // SQL query to insert records into Teacher table
        String insertQuery = "INSERT INTO Teacher (TNo, TName, Subject) VALUES (?, ?, ?)";

        // Array of teacher details to be inserted
        String[][] teachers = {
                { "T001", "John Doe", "JAVA" },
                { "T002", "Alice Smith", "C++" },
                { "T003", "Emily Johnson", "Python" },
                { "T004", "Michael Brown", "JAVA" },
                { "T005", "Emma Wilson", "JAVA" }
        };

        // Create PreparedStatement
        PreparedStatement preparedStatement = connection.prepareStatement(insertQuery);

        // Insert records into Teacher table
        for (String[] teacher : teachers) {
            preparedStatement.setString(1, teacher[0]); // TNo
            preparedStatement.setString(2, teacher[1]); // TName
            preparedStatement.setString(3, teacher[2]); // Subject
            preparedStatement.executeUpdate();
        }

        System.out.println("Records inserted into Teacher table successfully!");
    }

    private static void displayJavaTeachers(Connection connection) throws SQLException {
        // SQL query to select details of teachers teaching "JAVA" subject
        String selectQuery = "SELECT * FROM Teacher WHERE Subject = 'JAVA'";

        // Create PreparedStatement
        PreparedStatement preparedStatement = connection.prepareStatement(selectQuery);

        // Execute the query
        ResultSet resultSet = preparedStatement.executeQuery();

        // Display details of teachers teaching "JAVA" subject
        System.out.println("\nDetails of teachers teaching 'JAVA' subject:");
        while (resultSet.next()) {
            String tNo = resultSet.getString("TNo");
            String tName = resultSet.getString("TName");
            String subject = resultSet.getString("Subject");
            System.out.println("Teacher No: " + tNo + ", Teacher Name: " + tName + ", Subject: " + subject);
        }
    }
}
