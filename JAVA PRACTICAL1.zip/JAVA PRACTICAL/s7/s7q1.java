//. Write a java program that implements a multi-thread application that has three threads. First thread generates random integer number after every one second, if the number is even; second thread computes the square of that number and prints it. If the number is odd, the third thread computes the cube of that number and prints it.

import java.util.Random;

class NumberGenerator implements Runnable {
    Random random = new Random();

    public void run() {
        try {
            while (true) {
                int randomNumber = random.nextInt(100);
                System.out.println("Generated Random: " + randomNumber);

                if (randomNumber % 2 == 0) {
                    synchronized (SquareCalculator.lock) {
                        SquareCalculator.number = randomNumber;
                        SquareCalculator.lock.notify();
                    }
                } else {
                    synchronized (CubeCaculator.lock) {
                        CubeCaculator.number = randomNumber;
                        CubeCaculator.lock.notify();
                    }
                }
                Thread.sleep(1000);
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}

class SquareCalculator implements Runnable {
    static Object lock = new Object();
    static int number;

    public void run() {
        try {
            while (true) {
                synchronized (lock) {
                    lock.wait();
                    System.out.println("Square of " + number + " is : " + (number * number));
                }
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}

class CubeCaculator implements Runnable {
    static Object lock = new Object();
    static int number;

    public void run() {
        try {
            while (true) {
                synchronized (lock) {
                    lock.wait();
                    System.out.println("Cube of " + number + " is : " + (number * number * number));
                }
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}

public class s7q1 {
    public static void main(String[] args) {
        NumberGenerator numGenerator = new NumberGenerator();
        SquareCalculator sqCalculator = new SquareCalculator();
        CubeCaculator cubeCalculator = new CubeCaculator();

        Thread t1 = new Thread(numGenerator);
        Thread t2 = new Thread(sqCalculator);
        Thread t3 = new Thread(cubeCalculator);

        t1.start();
        t2.start();
        t3.start();
    }
}