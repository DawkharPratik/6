
/*
 * Write a java program for the following:
i. To create a Product (Pid, Pname, Price) table.
ii. Insert at least five records into the Product table.
iii. Display all the records from a Product table.
Assume Database is already created.
 */

import java.sql.*;

public class s7q2 {

    public static void main(String[] args) {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/tybcs", "root", "Ganesh");
            Statement st = con.createStatement();

            String createTableQuery = "CREATE TABLE IF NOT EXISTS Product(Pid int,Pname varchar(20),Price int)";
            st.executeUpdate(createTableQuery);

            st.executeUpdate("insert into Product values(1,'Apple',123)");

            ResultSet rs = st.executeQuery("select * from Product");

            System.out.println(" PID\tPname\tPrice");

            while (rs.next()) {
                System.out.println(" " + rs.getInt(1));
                System.out.println(" " + rs.getString(2));
                System.out.println(" " + rs.getInt(3));
                System.out.println();
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}