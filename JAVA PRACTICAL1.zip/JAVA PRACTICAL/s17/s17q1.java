
//Write a java program to accept ‘N’ integers from a user. Store and display integers in sorted order having proper collection class. The collection should not accept duplicate elements. 
import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;

public class s17q1 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the number of integers (N): ");
        int N = scanner.nextInt();

        Set<Integer> numbers = new TreeSet<>();

        System.out.println("Enter " + N + " integers:");
        for (int i = 0; i < N; i++) {
            int num = scanner.nextInt();
            numbers.add(num); // TreeSet automatically sorts and removes duplicates
        }

        System.out.println("Sorted unique integers:");
        for (int number : numbers) {
            System.out.println(number);
        }

        scanner.close();
    }
}
